//
//  ViewController.h
//  MainMenuTest
//
//  Created by Tverbakk, Veronica, Kristine on 2/14/13.
//  Copyright (c) 2013 Tverbakk, Veronica, Kristine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBAction UITableView *TableView;
@property (weak, nonatomic) IBAction UIView *AsthmaButton;
@property (weak, nonatomic) IBAction UIButton *Button1_1;
@property (weak, nonatomic) IBAction UIButton *Button1_2;
@property (weak, nonatomic) IBAction UIButton *Button1_3;

@end
